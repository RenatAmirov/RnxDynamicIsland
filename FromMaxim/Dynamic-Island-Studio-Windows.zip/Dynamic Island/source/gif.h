#pragma once
#include <windows.h>
#include <objidl.h>
#include <gdiplus.h>
#include <shlwapi.h>
#include <wrl/client.h>
#include <algorithm>
#include <memory>
#include <vector>

class GifArtwork {
public:
    void load(std::shared_ptr<const std::vector<unsigned char>> bytes) {
        if (bytes == bytes_) return;
        bytes_ = std::move(bytes);
        scaled_.reset();
        image_.reset();
        stream_.Reset();
        delays_.clear();
        index_ = 0;
        clock_ = 0;
        if (!bytes_) return;
        stream_.Attach(SHCreateMemStream(bytes_->data(), static_cast<UINT>(bytes_->size())));
        if (!stream_) return;
        auto image = std::make_unique<Gdiplus::Bitmap>(stream_.Get(), FALSE);
        if (image->GetLastStatus() != Gdiplus::Ok || image->GetWidth() == 0 || image->GetHeight() == 0 ||
            image->GetWidth() > 1024 || image->GetHeight() > 1024) return;
        UINT frames = image->GetFrameCount(&Gdiplus::FrameDimensionTime);
        if (!frames) frames = 1;
        if (frames > 500) return;
        delays_.assign(frames, .10f);
        const auto size = image->GetPropertyItemSize(PropertyTagFrameDelay);
        if (size >= sizeof(Gdiplus::PropertyItem) && size < 16384) {
            std::vector<unsigned char> buffer(size);
            auto item = reinterpret_cast<Gdiplus::PropertyItem*>(buffer.data());
            if (image->GetPropertyItem(PropertyTagFrameDelay, size, item) == Gdiplus::Ok && item->value) {
                auto values = static_cast<const ULONG*>(item->value);
                for (size_t i = 0; i < std::min<size_t>(frames, item->length / sizeof(ULONG)); ++i)
                    delays_[i] = std::clamp(static_cast<float>(values[i]) / 100.f, .02f, 10.f);
            }
        }
        image_ = std::move(image);
        scaleFrame();
    }

    void tick(float delta, bool animate, int speed) {
        if (!image_ || delays_.size() < 2) return;
        if (!animate) {
            if (index_ != 0 && image_->SelectActiveFrame(&Gdiplus::FrameDimensionTime, 0) == Gdiplus::Ok)
                scaleFrame();
            index_ = 0;
            clock_ = 0;
            return;
        }
        clock_ += delta * static_cast<float>(speed) / 100.f;
        auto next = index_;
        while (clock_ >= delays_[next]) {
            clock_ -= delays_[next];
            next = (next + 1) % delays_.size();
        }
        if (next != index_ && image_->SelectActiveFrame(&Gdiplus::FrameDimensionTime, static_cast<UINT>(next)) == Gdiplus::Ok) {
            index_ = next;
            scaleFrame();
        }
    }

    Gdiplus::Bitmap* image() const { return scaled_ ? scaled_.get() : image_.get(); }

private:
    void scaleFrame() {
        const auto width = image_->GetWidth(), height = image_->GetHeight();
        const auto largest = std::max(width, height);
        if (largest <= 96) return;
        if (!scaled_) scaled_ = std::make_unique<Gdiplus::Bitmap>(int(std::max(1U, width * 96 / largest)),
            int(std::max(1U, height * 96 / largest)), PixelFormat32bppPARGB);
        Gdiplus::Graphics graphics(scaled_.get());
        graphics.Clear(Gdiplus::Color(0, 0, 0, 0));
        graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBilinear);
        graphics.DrawImage(image_.get(), 0, 0, int(scaled_->GetWidth()), int(scaled_->GetHeight()));
    }

    std::shared_ptr<const std::vector<unsigned char>> bytes_;
    Microsoft::WRL::ComPtr<IStream> stream_;
    std::unique_ptr<Gdiplus::Bitmap> image_;
    std::unique_ptr<Gdiplus::Bitmap> scaled_;
    std::vector<float> delays_;
    size_t index_{};
    float clock_{};
};
