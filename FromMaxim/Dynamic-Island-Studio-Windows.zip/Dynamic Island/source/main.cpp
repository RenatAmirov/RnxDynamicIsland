#include <windows.h>
#include <windowsx.h>
#include <objidl.h>
#include <gdiplus.h>
#include <commdlg.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <wrl/client.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <memory>
#include <optional>
#include "browser.h"
#include "custom.h"
#include "gif.h"
#include "media.h"

using namespace Gdiplus;
using Clock = std::chrono::steady_clock;
using namespace std::chrono_literals;

namespace {
constexpr wchar_t key[] = L"Software\\DynamicIsland";
constexpr UINT_PTR modalFrameTimer = 1;
constexpr float canvasInset = 46.f;
enum class Action { None, Lock, Previous, Play, Next, Web, File, Timer, Close, Settings };
enum class Capsule { Mini, Track, Player };

void store(const wchar_t* name, DWORD value) {
    RegSetKeyValueW(HKEY_CURRENT_USER, key, name, REG_DWORD, &value, sizeof(value));
}

std::optional<DWORD> load(const wchar_t* name) {
    DWORD value{}, bytes = sizeof(value);
    if (RegGetValueW(HKEY_CURRENT_USER, key, name, RRF_RT_REG_DWORD, nullptr, &value, &bytes) == ERROR_SUCCESS)
        return value;
    return std::nullopt;
}

RECT workArea(POINT point) {
    MONITORINFO info{sizeof(info)};
    GetMonitorInfoW(MonitorFromPoint(point, MONITOR_DEFAULTTONEAREST), &info);
    return info.rcWork;
}

void rounded(GraphicsPath& path, RectF rect, float radius) {
    const float d = 2 * radius;
    path.AddArc(rect.X, rect.Y, d, d, 180, 90);
    path.AddArc(rect.GetRight() - d, rect.Y, d, d, 270, 90);
    path.AddArc(rect.GetRight() - d, rect.GetBottom() - d, d, d, 0, 90);
    path.AddArc(rect.X, rect.GetBottom() - d, d, d, 90, 90);
    path.CloseFigure();
}

void pill(Graphics& g, RectF rect, float radius, Color color) {
    GraphicsPath path;
    rounded(path, rect, radius);
    SolidBrush brush(color);
    g.FillPath(&brush, &path);
}

struct Surface {
    HDC dc = CreateCompatibleDC(nullptr);
    HBITMAP image{}, original{};
    void* pixels{};
    int width{}, height{};

    ~Surface() {
        if (original) SelectObject(dc, original);
        if (image) DeleteObject(image);
        DeleteDC(dc);
    }

    bool resize(int w, int h) {
        if (image && w == width && h == height) return true;
        BITMAPINFO info{};
        info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        info.bmiHeader.biWidth = w;
        info.bmiHeader.biHeight = -h;
        info.bmiHeader.biPlanes = 1;
        info.bmiHeader.biBitCount = 32;
        info.bmiHeader.biCompression = BI_RGB;
        auto bitmap = CreateDIBSection(dc, &info, DIB_RGB_COLORS, &pixels, nullptr, 0);
        if (!bitmap) return false;
        const auto old = static_cast<HBITMAP>(SelectObject(dc, bitmap));
        if (image) DeleteObject(old);
        else original = old;
        image = bitmap;
        width = w;
        height = h;
        return true;
    }
};

class Island {
public:
    Island() : editor_(appearance_, [this] { applyAppearance(); }) {
        wchar_t executable[32768]{};
        GetModuleFileNameW(nullptr, executable, static_cast<DWORD>(std::size(executable)));
        const auto font = std::filesystem::path(executable).parent_path() / L"assets" / L"Inter.ttf";
        fonts_.AddFontFile(font.c_str());
        int count{};
        fonts_.GetFamilies(1, &family_, &count);
        customFont_ = count > 0;
        const auto folder = settingsFolder();
        if (!folder.empty()) {
            appearancePath_ = folder / L"Current.island";
            readPreset(appearancePath_, appearance_);
        }
        gif_.load(appearance_.gif);
    }

    ~Island() {
        if (saveAppearanceAt_ != Clock::time_point{}) writePreset(appearancePath_, appearance_);
    }

    HWND open(HINSTANCE instance) {
        WNDCLASSW wc{};
        wc.hInstance = instance;
        wc.lpszClassName = L"DynamicIsland.Native";
        wc.lpfnWndProc = route;
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
        if (!RegisterClassW(&wc)) return nullptr;
        window_ = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_LAYERED | WS_EX_NOACTIVATE,
            wc.lpszClassName, L"Dynamic Island", WS_POPUP, 0, 0, 130, 34,
            nullptr, nullptr, instance, this);
        if (!window_) return nullptr;
        dpi_ = GetDpiForWindow(window_);
        if (!dpi_) dpi_ = 96;
        locked_ = load(L"Locked").value_or(0) != 0;
        if (const auto x = load(L"X"), y = load(L"Y"); x && y)
            place(float(static_cast<LONG>(*x)), float(static_cast<LONG>(*y)), false);
        else
            reset();
        anchorX_ = targetX_;
        anchorY_ = targetY_;
        x_ = targetX_;
        y_ = targetY_;
        frame();
        ShowWindow(window_, SW_SHOWNOACTIVATE);
        return window_;
    }

    int run() {
        HANDLE timer = CreateWaitableTimerExW(nullptr, nullptr, CREATE_WAITABLE_TIMER_HIGH_RESOLUTION,
                                              TIMER_MODIFY_STATE | SYNCHRONIZE);
        if (!timer)
            timer = CreateWaitableTimerW(nullptr, FALSE, nullptr);
        auto nextFrame = Clock::now();
        for (;;) {
            MSG message{};
            for (int i = 0; i < 64 && PeekMessageW(&message, nullptr, 0, 0, PM_REMOVE); ++i) {
                if (message.message == WM_QUIT) {
                    if (timer) CloseHandle(timer);
                    return static_cast<int>(message.wParam);
                }
                TranslateMessage(&message);
                DispatchMessageW(&message);
            }

            const auto now = Clock::now();
            if (now >= nextFrame) {
                frame();
                const auto interval = frameInterval();
                nextFrame += interval;
                if (nextFrame <= now) nextFrame = now + interval;
            }
            const auto delay = nextFrame - Clock::now();
            if (delay <= Clock::duration::zero()) continue;
            using TimerTick = std::chrono::duration<long long, std::ratio<1, 10000000>>;
            LARGE_INTEGER due{};
            due.QuadPart = -std::max(1LL, std::chrono::ceil<TimerTick>(delay).count());
            if (timer && SetWaitableTimer(timer, &due, 0, nullptr, nullptr, FALSE)) {
                MsgWaitForMultipleObjectsEx(1, &timer, INFINITE, QS_ALLINPUT, MWMO_INPUTAVAILABLE);
            } else {
                const auto ms = static_cast<DWORD>(std::chrono::ceil<std::chrono::milliseconds>(delay).count());
                MsgWaitForMultipleObjectsEx(0, nullptr, ms, QS_ALLINPUT, MWMO_INPUTAVAILABLE);
            }
        }
    }

    void openAudio(std::wstring path) {
        media_.open(std::move(path));
    }

private:
    static LRESULT CALLBACK route(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
        if (msg == WM_NCCREATE) {
            const auto create = reinterpret_cast<CREATESTRUCTW*>(l);
            const auto self = static_cast<Island*>(create->lpCreateParams);
            self->window_ = hwnd;
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
        }
        const auto self = reinterpret_cast<Island*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
        return self ? self->message(msg, w, l) : DefWindowProcW(hwnd, msg, w, l);
    }

    LRESULT message(UINT msg, WPARAM w, LPARAM l) {
        switch (msg) {
        case WM_TIMER:
            if (w == modalFrameTimer) frame();
            return 0;
        case WM_MOUSEACTIVATE: return MA_NOACTIVATE;
        case WM_DPICHANGED:
            dpi_ = LOWORD(w);
            if (!dragging_) place(targetX_, targetY_, false);
            return 0;
        case WM_DISPLAYCHANGE:
        case WM_SETTINGCHANGE:
            refreshMonitor_ = nullptr;
            place(targetX_, targetY_, false);
            return 0;
        case WM_LBUTTONDOWN:
            GetCursorPos(&start_);
            held_ = true;
            physicalPress_ = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
            movedEnough_ = false;
            pressed_ = hit(l);
            grabX_ = float(start_.x) - x_;
            grabY_ = float(start_.y) - y_;
            SetCapture(window_);
            return 0;
        case WM_MOUSEMOVE:
            if (held_) trackPointer();
            return 0;
        case WM_LBUTTONUP:
            if (held_) {
                const auto action = hit(l);
                const bool click = !movedEnough_ && !dragging_ && action == pressed_;
                finishPointer();
                if (click) activate(action);
            }
            return 0;
        case WM_CAPTURECHANGED:
            if (held_ && !physicalPress_) finishPointer();
            return 0;
        case WM_RBUTTONUP: menu(); return 0;
        case WM_CLOSE: DestroyWindow(window_); return 0;
        case WM_DESTROY:
            browser_.close();
            PostQuitMessage(0);
            return 0;
        }
        return DefWindowProcW(window_, msg, w, l);
    }

    float scale() const { return float(dpi_) / 96.f; }

    Clock::duration frameInterval() {
        const auto monitor = MonitorFromWindow(window_, MONITOR_DEFAULTTONEAREST);
        if (monitor != refreshMonitor_) {
            refreshMonitor_ = monitor;
            MONITORINFOEXW info{};
            info.cbSize = sizeof(info);
            DEVMODEW mode{};
            mode.dmSize = sizeof(mode);
            refreshRate_ = 60;
            if (GetMonitorInfoW(monitor, &info) &&
                EnumDisplaySettingsW(info.szDevice, ENUM_CURRENT_SETTINGS, &mode) &&
                (mode.dmFields & DM_DISPLAYFREQUENCY) && mode.dmDisplayFrequency > 1) {
                refreshRate_ = mode.dmDisplayFrequency;
            }
        }
        return std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(1.0 / refreshRate_));
    }

    void trackPointer() {
        POINT point{};
        GetCursorPos(&point);
        movedEnough_ = movedEnough_ || std::abs(point.x - start_.x) + std::abs(point.y - start_.y) >= 5;
        if (movedEnough_ && !locked_ && pressed_ == Action::None) {
            dragging_ = true;
            place(float(point.x) - grabX_, float(point.y) - grabY_, false);
        }
    }

    void finishPointer() {
        const bool moved = dragging_;
        held_ = dragging_ = physicalPress_ = false;
        if (GetCapture() == window_) ReleaseCapture();
        if (moved) {
            place(targetX_, targetY_, true);
            rememberPosition();
        }
        showTrackUntil_ = Clock::now() + std::chrono::seconds(appearance_.idleSeconds);
    }

    void place(float x, float y, bool snap) {
        const auto area = workArea({std::lround(x), std::lround(y + 12 * scale())});
        const float half = (expanded_ ? appearance_.playerWidth : appearance_.trackWidth) * scale() / 2.f;
        const float height = (expanded_ ? stateHeight(Capsule::Player) : 58.f) * scale();
        const float left = std::min(float(area.left) + half, float(area.left + area.right) / 2);
        const float right = std::max(float(area.right) - half, left);
        const float top = float(area.top + 6);
        const float bottom = std::max(float(area.bottom) - height - 6, top);
        targetX_ = std::clamp(x, left, right);
        targetY_ = std::clamp(y, top, bottom);
        if (snap && targetY_ - top < 22 * scale()) targetY_ = top;
    }

    void reset() {
        const auto area = workArea({0, 0});
        place(float(area.left + area.right) / 2, float(area.top + 8), false);
    }

    void save() const {
        store(L"X", static_cast<DWORD>(std::lround(anchorX_)));
        store(L"Y", static_cast<DWORD>(std::lround(anchorY_)));
        store(L"Locked", locked_ ? 1 : 0);
    }

    Action hit(LPARAM l) const {
        const PointF point(float(GET_X_LPARAM(l)) / scale() - canvasInset,
                           float(GET_Y_LPARAM(l)) / scale() - canvasInset);
        for (size_t i = 0; i < hitCount_; ++i)
            if (hits_[i].rect.Contains(point)) return hits_[i].action;
        return Action::None;
    }

    void chooseFile() {
        wchar_t path[32768]{};
        OPENFILENAMEW file{sizeof(file)};
        file.hwndOwner = window_;
        file.lpstrFile = path;
        file.nMaxFile = static_cast<DWORD>(std::size(path));
        file.lpstrFilter = L"Audio files\0*.mp3;*.flac;*.wav;*.m4a;*.aac;*.ogg;*.wma;*.opus\0All files\0*.*\0";
        file.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
        SetTimer(window_, modalFrameTimer, 15, nullptr);
        const auto chosen = GetOpenFileNameW(&file);
        KillTimer(window_, modalFrameTimer);
        if (chosen) media_.open(path);
    }

    void setExpanded(bool value) {
        expanded_ = value;
        if (!value) browser_.close();
        showTrackUntil_ = Clock::now() + std::chrono::seconds(appearance_.idleSeconds);
        // Keep the saved position as the anchor while the expanded view fits on screen.
        place(anchorX_, anchorY_, false);
    }

    RECT browserAnchor() const {
        const auto padding = std::lround(canvasInset * scale());
        return {rect_.left + padding, rect_.top + padding, rect_.right - padding, rect_.bottom - padding};
    }

    void activate(Action action) {
        switch (action) {
        case Action::None:
            if (expanded_ || appearance_.click) setExpanded(!expanded_);
            else showTrackUntil_ = Clock::now() + std::chrono::seconds(std::max(4, appearance_.idleSeconds));
            break;
        case Action::Close: setExpanded(false); break;
        case Action::Settings: editor_.open(window_); break;
        case Action::Lock: locked_ = !locked_; save(); break;
        case Action::Previous: if (current_.previous) media_.send(Media::Command::Previous); break;
        case Action::Play: if (current_.toggle) media_.send(Media::Command::Toggle); break;
        case Action::Next: if (current_.next) media_.send(Media::Command::Next); break;
        case Action::Web:
            if (browser_.visible()) browser_.close();
            else browser_.open(window_, browserAnchor());
            break;
        case Action::File: chooseFile(); break;
        case Action::Timer:
            if (deadline_ > Clock::now()) deadline_ = {};
            else deadline_ = Clock::now() + 5min;
            timerFinished_ = false;
            break;
        }
    }

    void menu() {
        const auto menu = CreatePopupMenu();
        AppendMenuW(menu, MF_STRING | (locked_ ? MF_CHECKED : 0), 1, L"Lock position");
        AppendMenuW(menu, MF_STRING, 2, L"Reset position");
        AppendMenuW(menu, MF_STRING, 3, L"Open browser");
        AppendMenuW(menu, MF_STRING, 4, L"Open music file...");
        AppendMenuW(menu, MF_STRING, 5, L"Open Spotify Web");
        AppendMenuW(menu, MF_STRING, 7, L"Use Windows media session");
        AppendMenuW(menu, MF_STRING, 8, L"Customize island...");
        AppendMenuW(menu, MF_STRING, 9, L"Show player");
        const auto presets = namedPresets();
        if (!presets.empty()) {
            const auto list = CreatePopupMenu();
            for (size_t i = 0; i < std::min<size_t>(presets.size(), 30); ++i)
                AppendMenuW(list, MF_STRING, 100 + i, presets[i].stem().c_str());
            AppendMenuW(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(list), L"Presets");
        }
        AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
        AppendMenuW(menu, MF_STRING, 6, L"Quit Dynamic Island");
        POINT p{};
        GetCursorPos(&p);
        SetForegroundWindow(window_);
        SetTimer(window_, modalFrameTimer, 15, nullptr);
        const auto command = TrackPopupMenu(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_NONOTIFY,
                                            p.x, p.y, 0, window_, nullptr);
        KillTimer(window_, modalFrameTimer);
        DestroyMenu(menu);
        switch (command) {
        case 1: activate(Action::Lock); break;
        case 2: reset(); rememberPosition(); break;
        case 3: setExpanded(true); browser_.open(window_, browserAnchor()); break;
        case 4: chooseFile(); break;
        case 5: setExpanded(true); browser_.open(window_, browserAnchor(), L"https://open.spotify.com/"); break;
        case 6: PostMessageW(window_, WM_CLOSE, 0, 0); break;
        case 7: media_.send(Media::Command::ReleaseLocal); break;
        case 8: editor_.open(window_); break;
        case 9: setExpanded(true); break;
        default:
            if (command >= 100 && command - 100 < presets.size() && readPreset(presets[command - 100], appearance_)) {
                applyAppearance();
                editor_.refresh();
            }
            break;
        }
    }

    void rememberPosition() {
        anchorX_ = targetX_;
        anchorY_ = targetY_;
        save();
    }

    void label(Graphics& g, const std::wstring& value, RectF area, float size,
               Color color, bool bold = false, bool centered = false) const {
        FontFamily fallback(appearance_.font == 2 ? L"Consolas" : L"Segoe UI");
        size *= appearance_.fontSize / 100.f;
        Font font(customFont_ && appearance_.font == 0 ? &family_ : &fallback, size, bold ? FontStyleBold : FontStyleRegular, UnitPixel);
        if (font.GetLastStatus() != Ok) {
            Font systemFont(&fallback, size, bold ? FontStyleBold : FontStyleRegular, UnitPixel);
            drawLabel(g, value, area, color, centered, systemFont);
        } else {
            drawLabel(g, value, area, color, centered, font);
        }
    }

    static void drawLabel(Graphics& g, const std::wstring& value, RectF area, Color color,
                          bool centered, const Font& font) {
        StringFormat format;
        format.SetFormatFlags(StringFormatFlagsNoWrap);
        format.SetTrimming(StringTrimmingEllipsisCharacter);
        format.SetLineAlignment(StringAlignmentCenter);
        if (centered) format.SetAlignment(StringAlignmentCenter);
        SolidBrush ink(color);
        g.DrawString(value.c_str(), -1, &font, area, &format, &ink);
    }

    std::wstring timerText(Clock::time_point now) const {
        if (timerFinished_) return L"Timer done";
        if (deadline_ <= now) return L"5 min timer";
        const auto remaining = std::chrono::ceil<std::chrono::seconds>(deadline_ - now).count();
        wchar_t time[16]{};
        swprintf_s(time, L"%lld:%02lld", remaining / 60, remaining % 60);
        return time;
    }

    void updateCover() {
        if (current_.cover == coverBytes_) return;
        cover_.reset();
        coverColor_ = 0;
        coverBytes_ = current_.cover;
        if (!coverBytes_) return;
        Microsoft::WRL::ComPtr<IStream> stream;
        stream.Attach(SHCreateMemStream(coverBytes_->data(), static_cast<UINT>(coverBytes_->size())));
        if (!stream) return;
        Bitmap image(stream.Get(), FALSE);
        if (image.GetLastStatus() != Ok || !image.GetWidth() || !image.GetHeight()) return;
        const float side = float(std::min(image.GetWidth(), image.GetHeight()));
        auto thumbnail = std::make_unique<Bitmap>(120, 120, PixelFormat32bppPARGB);
        {
            Graphics resize(thumbnail.get());
            resize.SetInterpolationMode(InterpolationModeHighQualityBicubic);
            if (resize.DrawImage(&image, RectF(0, 0, 120, 120), (float(image.GetWidth()) - side) / 2,
                                 (float(image.GetHeight()) - side) / 2, side, side, UnitPixel) != Ok) return;
        }
        unsigned red{}, green{}, blue{}, count{};
        for (int y = 12; y < 120; y += 16) {
            for (int x = 12; x < 120; x += 16) {
                Color sample;
                if (thumbnail->GetPixel(x, y, &sample) != Ok || sample.GetA() < 160) continue;
                red += sample.GetR(); green += sample.GetG(); blue += sample.GetB(); ++count;
            }
        }
        if (count) {
            const auto dark = [count](unsigned channel) { return 18 + channel * 36 / (count * 100); };
            coverColor_ = (dark(red) << 16) | (dark(green) << 8) | dark(blue);
        }
        cover_ = std::move(thumbnail);
    }

    void drawCover(Graphics& g, RectF rect, float opacity, Capsule state) {
        GraphicsPath path;
        rounded(path, rect, rect.Width * .25f);
        const auto clip = g.Save();
        g.SetClip(&path, CombineModeIntersect);
        Bitmap* icon = state != Capsule::Player && appearance_.icon == 2 ? gif_.image() : nullptr;
        Bitmap* image = icon ? icon : (state == Capsule::Player || appearance_.icon == 0) ? cover_.get() : nullptr;
        if (image) {
            ColorMatrix fade = {{{1, 0, 0, 0, 0}, {0, 1, 0, 0, 0}, {0, 0, 1, 0, 0},
                                {0, 0, 0, opacity, 0}, {0, 0, 0, 0, 1}}};
            ImageAttributes attributes;
            attributes.SetColorMatrix(&fade);
            g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
            const float iw = float(image->GetWidth()), ih = float(image->GetHeight());
            if (icon && appearance_.gifFit) {
                const float fit = rect.Width / std::max(iw, ih);
                const RectF destination(rect.X + (rect.Width - iw * fit) / 2, rect.Y + (rect.Height - ih * fit) / 2,
                                        iw * fit, ih * fit);
                g.DrawImage(image, destination, 0, 0, iw, ih, UnitPixel, &attributes);
            } else {
                const float side = std::min(iw, ih);
                g.DrawImage(image, rect, (iw - side) / 2, (ih - side) / 2, side, side, UnitPixel, &attributes);
            }
        } else {
            const auto a = static_cast<BYTE>(255 * opacity);
            LinearGradientBrush fill(rect, Color(a, 148, 79, 58), Color(a, 65, 40, 36), 55.f);
            g.FillRectangle(&fill, rect);
            Pen ring(Color(a, 243, 181, 143), 1.2f);
            g.DrawEllipse(&ring, rect.X + rect.Width * .22f, rect.Y + rect.Height * .22f,
                          rect.Width * .56f, rect.Height * .56f);
            g.DrawEllipse(&ring, rect.X + rect.Width * .43f, rect.Y + rect.Height * .43f,
                          rect.Width * .14f, rect.Height * .14f);
        }
        g.Restore(clip);
    }

    static void drawActionIcon(Graphics& g, Action action, float x, float y, Color color, bool playing) {
        Pen pen(color, 1.25f);
        pen.SetStartCap(LineCapRound);
        pen.SetEndCap(LineCapRound);
        SolidBrush fill(color);
        switch (action) {
        case Action::Previous:
        case Action::Next:
        case Action::Play: {
            if (action == Action::Play && playing) {
                g.FillRectangle(&fill, x - 4, y - 5, 2.5f, 10.f);
                g.FillRectangle(&fill, x + 1.5f, y - 5, 2.5f, 10.f);
                break;
            }
            const float direction = action == Action::Previous ? -1.f : 1.f;
            const PointF triangle[]{{x - 3 * direction, y - 5}, {x + 5 * direction, y}, {x - 3 * direction, y + 5}};
            g.FillPolygon(&fill, triangle, 3);
            if (action != Action::Play) g.DrawLine(&pen, x + 6 * direction, y - 4.5f, x + 6 * direction, y + 4.5f);
            break;
        }
        case Action::Web:
            g.DrawEllipse(&pen, x - 5.5f, y - 5.5f, 11.f, 11.f);
            g.DrawEllipse(&pen, x - 2.5f, y - 5.5f, 5.f, 11.f);
            g.DrawLine(&pen, x - 5, y, x + 5, y);
            break;
        case Action::File:
            g.DrawLine(&pen, x - 1, y + 2, x - 1, y - 5);
            g.DrawLine(&pen, x - 1, y - 5, x + 4, y - 3.5f);
            g.FillEllipse(&fill, x - 5.5f, y + 1, 5.f, 4.f);
            break;
        case Action::Timer:
            g.DrawEllipse(&pen, x - 5.2f, y - 5.2f, 10.4f, 10.4f);
            g.DrawLine(&pen, x, y - 2.8f, x, y);
            g.DrawLine(&pen, x, y, x + 2.1f, y + 1);
            break;
        default:
            break;
        }
    }


    struct Slot { char id; RectF rect; };
    struct Hit { Action action; RectF rect; };

    float stateWidth(Capsule state) const {
        switch (state) {
        case Capsule::Mini: return float(appearance_.miniWidth);
        case Capsule::Track: return float(appearance_.trackWidth);
        case Capsule::Player: return float(appearance_.playerWidth);
        }
        return 96;
    }

    std::vector<Slot> slots(Capsule state) const {
        std::vector<Slot> result;
        result.reserve(8);
        const auto& order = appearance_.blocks[static_cast<size_t>(state)];
        const bool player = state == Capsule::Player;
        const float pad = player ? float(appearance_.padding) : std::min(13.f, appearance_.padding * .8f);
        const float available = stateWidth(state) - 2 * pad;
        const float gap = player ? 7.f : std::min(6.f, available / 36);
        if (!player) {
            const auto size = [state](char id) {
                switch (id) {
                case 'A': return state == Capsule::Mini ? 24.f : 28.f;
                case 'T': return state == Capsule::Mini ? 42.f : 122.f;
                case 'S': return 74.f;
                case 'M': return 23.f;
                case 'P': return 69.f;
                case 'C': return 48.f;
                default: return 28.f;
                }
            };
            float needed = gap * float(order.size() - 1);
            for (const auto id : order) needed += size(id);
            const float ratio = std::min(1.f, available / needed);
            const float spare = std::max(0.f, available - needed);
            const bool stretchTitle = order.find('T') != std::string::npos;
            float x = pad + (stretchTitle ? 0.f : spare / 2);
            const float rowHeight = state == Capsule::Mini ? 36.f : 45.f;
            for (const char id : order) {
                const float w = size(id) * ratio + (id == 'T' ? spare : 0.f);
                result.push_back({id, {x, 0, w, rowHeight}});
                x += w + gap * ratio;
            }
            return result;
        }

        float x = pad, y = 45, rowHeight = 0;
        const auto nextRow = [&] {
            if (!rowHeight) return;
            x = pad;
            y += rowHeight + gap;
            rowHeight = 0;
        };
        for (size_t i = 0; i < order.size(); ++i) {
            char id = order[i];
            if (id == 'T' && i + 1 < order.size() && order[i + 1] == 'S') {
                id = 'H';
                ++i;
            }
            const bool longText = id == 'T' || id == 'S' || id == 'H';
            const float height = id == 'A' || longText ? 58.f : id == 'P' ? 36.f : 32.f;
            float w = id == 'A' ? 58.f : longText ? std::min(available - 65, 242.f) :
                      id == 'M' ? 48.f : id == 'P' ? 114.f : std::min(122.f, (available - 2 * gap) / 3);
            if (id == 'P' || x + w > pad + available) nextRow();
            if (id == 'P') x = (stateWidth(state) - w) / 2;
            result.push_back({id, {x, y, w, height}});
            x += w + gap;
            rowHeight = std::max(rowHeight, height);
            if (id == 'P') nextRow();
        }
        return result;
    }

    float stateHeight(Capsule state) const {
        if (state == Capsule::Mini) return 36.f;
        if (state == Capsule::Track) return 45.f;
        const auto layout = slots(state);
        float bottom = 45;
        for (const auto& slot : layout) bottom = std::max(bottom, slot.rect.GetBottom());
        return bottom + appearance_.padding;
    }

    void applyAppearance() {
        gif_.load(appearance_.gif);
        saveAppearanceAt_ = Clock::now() + 280ms;
        showTrackUntil_ = Clock::now() + std::chrono::seconds(appearance_.idleSeconds);
        place(anchorX_, anchorY_, false);
    }

    static Color faded(float alpha, unsigned rgb) {
        return Color(static_cast<BYTE>(255 * std::clamp(alpha, 0.f, 1.f)), BYTE(rgb >> 16), BYTE(rgb >> 8), BYTE(rgb));
    }

    void drawButton(Graphics& g, Action action, RectF rect, const std::wstring& text, float opacity, bool active,
                    bool interactive, PointF mouse) {
        if (rect.Width < 12.f || rect.Height < 10.f) return;
        if (interactive && hitCount_ < hits_.size()) hits_[hitCount_++] = {action, rect};
        const bool hover = interactive && active && rect.Contains(mouse);
        const bool emphasis = action == Action::Play || (action == Action::Web && browser_.visible()) ||
                              (action == Action::Lock && locked_);
        pill(g, rect, std::min(10.f, rect.Width / 3), faded(opacity * (hover ? .36f : emphasis ? .28f : .13f), 0xE4A07B));
        const auto ink = faded(opacity * (active ? 1.f : .35f), 0xFCF1E6);
        if (text.empty()) {
            drawActionIcon(g, action, rect.X + rect.Width / 2, rect.Y + rect.Height / 2, ink, current_.playing);
        } else if (rect.Width < 43.f && (action == Action::Web || action == Action::File || action == Action::Timer)) {
            drawActionIcon(g, action, rect.X + rect.Width / 2, rect.Y + rect.Height / 2, ink, false);
        } else {
            label(g, text, rect, rect.Width < 44.f ? 9.f : 11.f, ink, true, true);
        }
    }

    void renderBlocks(Graphics& g, Capsule state, float opacity, float seconds, Clock::time_point now, bool interactive) {
        if (opacity < .01f) return;
        const float dx = (width_ - stateWidth(state)) / 2;
        const float dy = state == Capsule::Player ? 0.f : (height_ - stateHeight(state)) / 2;
        const auto fg = faded(opacity, 0xFCF1E6), muted = faded(opacity, 0xC9B0A0);
        POINT pointer{};
        GetCursorPos(&pointer);
        const PointF mouse(float(pointer.x - rect_.left) / scale() - canvasInset,
                           float(pointer.y - rect_.top) / scale() - canvasInset);
        if (state == Capsule::Player) {
            const float edge = stateWidth(state) + dx - appearance_.padding;
            label(g, battery_.empty() ? L"NOW PLAYING" : battery_, {dx + appearance_.padding, 11, 168, 22}, 9, muted, true);
            drawButton(g, Action::Settings, {edge - 113, 11, 45, 25}, L"SET", opacity, true, interactive, mouse);
            drawButton(g, Action::Lock, {edge - 62, 11, 34, 25}, locked_ ? L"PIN" : L"FREE", opacity, true, interactive, mouse);
            drawButton(g, Action::Close, {edge - 23, 11, 23, 25}, L"⌃", opacity, true, interactive, mouse);
        }
        const auto title = current_.title.empty() ? (deadline_ > now || timerFinished_ ? timerText(now) :
            current_.active ? L"Now playing" : L"No media playing") : current_.title;
        for (auto [id, r] : slots(state)) {
            r.X += dx; r.Y += dy;
            const float center = r.Y + r.Height / 2;
            switch (id) {
            case 'A': {
                const float side = std::min({r.Width, r.Height, state == Capsule::Player ? 58.f : 28.f});
                if (side >= 5) drawCover(g, {r.X, center - side / 2, side, side}, opacity, state);
                break;
            }
            case 'T': label(g, title, r, state == Capsule::Player ? 18.f : 13.f, fg, true); break;
            case 'S': label(g, current_.artist, r, 11, muted); break;
            case 'H':
                label(g, title, {r.X, center - 22, r.Width, 26}, 18, fg, true);
                label(g, current_.artist, {r.X, center + 3, r.Width, 19}, 11, muted);
                break;
            case 'M':
                for (int i = 0; i < 4; ++i) {
                    const float bar = current_.playing ? 5 + 11 * std::abs(std::sin(seconds * (5 + i) + i)) : 4;
                    pill(g, {r.X + r.Width / 2 - 9 + i * 5.f, center - bar / 2, 2.5f, bar}, 1.2f, faded(opacity, 0xE5966D));
                }
                break;
            case 'P': {
                const float part = r.Width / 3;
                drawButton(g, Action::Previous, {r.X, center - 14, part - 2, 28}, L"", opacity, current_.previous, interactive, mouse);
                drawButton(g, Action::Play, {r.X + part, center - 16, part - 2, 32}, L"", opacity, current_.toggle, interactive, mouse);
                drawButton(g, Action::Next, {r.X + 2 * part, center - 14, part - 2, 28}, L"", opacity, current_.next, interactive, mouse);
                break;
            }
            case 'B': drawButton(g, Action::Web, {r.X, center - 14, r.Width, 28}, browser_.visible() ? L"Hide browser" : L"Browser",
                                 opacity, true, interactive, mouse); break;
            case 'F': drawButton(g, Action::File, {r.X, center - 14, r.Width, 28}, L"Open music", opacity, true, interactive, mouse); break;
            case 'C': drawButton(g, Action::Timer, {r.X, center - 14, r.Width, 28}, timerText(now), opacity, true, interactive, mouse); break;
            }
        }
    }

    void paint(Graphics& g, float seconds, Clock::time_point now) {
        const float radius = std::min({height_ / 2, width_ / 2, float(appearance_.radius)});
        GraphicsPath shape;
        rounded(shape, {.6f, .6f, width_ - 1.2f, height_ - 1.2f}, radius - .6f);
        const auto background = g.Save();
        const float cx = width_ / 2, cy = height_ / 2;
        Matrix stretch(1 + stretchX_, stretchCross_, stretchCross_, 1 + stretchY_,
                       -cx * stretchX_ - cy * stretchCross_ + trailX_,
                       -cx * stretchCross_ - cy * stretchY_ + trailY_);
        g.MultiplyTransform(&stretch);
        const float angle = .57f + (appearance_.gradient ? .32f * std::sin(seconds * .47f) : 0.f);
        const float span = .54f * std::hypot(width_, height_);
        const float dx = span * std::cos(angle), dy = span * std::sin(angle);
        const float opacity = appearance_.opacity / 100.f;
        const auto first = appearance_.artPalette && coverColor_ ? coverColor_ : appearance_.first;
        LinearGradientBrush gradient(PointF(cx - dx, cy - dy), PointF(cx + dx, cy + dy),
                                     faded(opacity, first), faded(opacity, appearance_.second));
        gradient.SetGammaCorrection(TRUE);
        g.FillPath(&gradient, &shape);
        if (appearance_.outline) {
            Pen border(faded(.37f + .35f * grip_, 0xE3B398), 1.f + grip_ * .55f);
            g.DrawPath(&border, &shape);
        }
        g.Restore(background);
        g.SetClip(&shape);
        hitCount_ = 0;
        if (lastState_ != state_) renderBlocks(g, lastState_, 1 - blend_, seconds, now, false);
        renderBlocks(g, state_, blend_, seconds, now, blend_ > .58f);
    }

    void frame() {
        // A non-activating overlay can lose capture when the cursor outruns it.
        if (held_ && physicalPress_) {
            if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) trackPointer();
            else if (GetCapture() != window_) finishPointer();
        }
        const auto now = Clock::now();
        const float dt = std::clamp(std::chrono::duration<float>(now - last_).count(), .001f, .08f);
        const float seconds = std::chrono::duration<float>(now - started_).count();
        last_ = now;
        if (saveAppearanceAt_ != Clock::time_point{} && now >= saveAppearanceAt_) {
            saveAppearanceAt_ = {};
            writePreset(appearancePath_, appearance_);
        }
        if (now >= nextStatus_) {
            const auto priorTitle = current_.title;
            const auto priorArtist = current_.artist;
            const bool previouslyActive = current_.active;
            current_ = media_.state();
            if (appearance_.trackWake && current_.active &&
                (!previouslyActive || priorTitle != current_.title || priorArtist != current_.artist)) {
                showTrackUntil_ = now + std::chrono::seconds(appearance_.idleSeconds);
            }
            updateCover();
            SYSTEM_POWER_STATUS power{};
            if (GetSystemPowerStatus(&power) && !(power.BatteryFlag & 128) && power.BatteryLifePercent <= 100) {
                battery_ = std::to_wstring(power.BatteryLifePercent) + L"%";
                if (power.ACLineStatus == 1) battery_ += L"  ·  Plugged in";
            } else {
                battery_.clear();
            }
            nextStatus_ = now + 500ms;
        }
        if (deadline_ != Clock::time_point{} && deadline_ <= now) {
            deadline_ = {};
            timerFinished_ = true;
            MessageBeep(MB_OK);
        }
        POINT mouse{};
        GetCursorPos(&mouse);
        const auto visibleRect = browserAnchor();
        const bool hovering = rect_.right > rect_.left && PtInRect(&visibleRect, mouse);
        if (appearance_.hover && hovering && !held_ && current_.active)
            showTrackUntil_ = now + std::chrono::seconds(appearance_.idleSeconds);
        const bool showTimer = deadline_ > now || timerFinished_;
        const bool showTrack = (current_.active && (!appearance_.idleSeconds || now < showTrackUntil_)) ||
                               (showTimer && !current_.active);
        const auto targetState = expanded_ ? Capsule::Player : showTrack ? Capsule::Track : Capsule::Mini;
        if (targetState != state_ && (!held_ || expanded_)) {
            lastState_ = state_;
            state_ = targetState;
            blend_ = 0;
        }
        const bool animateGif = appearance_.icon == 2 &&
            (state_ == Capsule::Mini ? appearance_.gifMini != 0 : state_ == Capsule::Track && appearance_.gifTrack != 0);
        gif_.tick(dt, animateGif, appearance_.gifSpeed);
        const auto ease = [dt](float from, float to, float speed) {
            if (std::abs(to - from) < .06f) return to;
            return to + (from - to) * std::exp(-speed * dt);
        };
        const float speed = appearance_.speed / 100.f;
        width_ = ease(width_, stateWidth(state_), 15 * speed);
        height_ = ease(height_, stateHeight(state_), 15 * speed);
        blend_ = std::min(1.f, blend_ + dt * 5 * speed);
        const float previousX = x_, previousY = y_;
        x_ = ease(x_, targetX_, dragging_ ? 31.f : 19.f);
        y_ = ease(y_, targetY_, dragging_ ? 31.f : 19.f);
        const float dx = x_ - previousX, dy = y_ - previousY;
        const float distance = std::hypot(dx, dy);
        const bool grabbed = held_ && !locked_ && pressed_ == Action::None;
        const float amount = appearance_.drag / 135.f;
        const float strength = dragging_ ? std::min(distance / (scale() * dt * 680.f), 1.f) : 0;
        const float ux = distance > .001f ? dx / distance : 0;
        const float uy = distance > .001f ? dy / distance : 0;
        const auto morph = [dt, grabbed](float from, float to) {
            return std::abs(from - to) < .0002f ? to : to + (from - to) * std::exp(-(grabbed ? 35.f : 21.f) * dt);
        };
        grip_ = morph(grip_, grabbed ? std::min(1.f, amount) : 0.f);
        const float squeeze = grip_ * (1 - .7f * strength);
        const float along = std::min(.20f, 62.f / width_);
        const float direction = strength * (along + .09f) * amount;
        stretchX_ = morph(stretchX_, squeeze * .06f + direction * ux * ux - strength * .09f * amount);
        stretchY_ = morph(stretchY_, -squeeze * .16f + direction * uy * uy - strength * .09f * amount);
        stretchCross_ = morph(stretchCross_, direction * ux * uy);
        trailX_ = morph(trailX_, -ux * 10 * strength * amount);
        trailY_ = morph(trailY_, -uy * 7 * strength * amount);
        const float extent = std::max(std::abs(stretchX_) * width_ / 2 + std::abs(stretchCross_) * height_ / 2 + std::abs(trailX_),
                                      std::abs(stretchY_) * height_ / 2 + std::abs(stretchCross_) * width_ / 2 + std::abs(trailY_));
        if (extent > canvasInset - 2) {
            const float limit = (canvasInset - 2) / extent;
            stretchX_ *= limit; stretchY_ *= limit; stretchCross_ *= limit;
            trailX_ *= limit; trailY_ *= limit;
        }
        const int w = int(std::ceil((width_ + 2 * canvasInset) * scale()));
        const int h = int(std::ceil((height_ + 2 * canvasInset) * scale()));
        POINT position{std::lround(x_ - float(w) / 2), std::lround(y_ - canvasInset * scale())};
        SIZE size{w, h};
        const RECT updated{position.x, position.y, position.x + w, position.y + h};
        const bool moved = !EqualRect(&rect_, &updated);
        rect_ = updated;
        if (!surface_.resize(w, h)) return;
        {
            Bitmap bitmap(w, h, w * 4, PixelFormat32bppPARGB, static_cast<BYTE*>(surface_.pixels));
            Graphics g(&bitmap);
            g.Clear(Color(0, 0, 0, 0));
            g.SetSmoothingMode(SmoothingModeAntiAlias);
            g.SetTextRenderingHint(TextRenderingHintAntiAliasGridFit);
            g.ScaleTransform(scale(), scale());
            g.TranslateTransform(canvasInset, canvasInset);
            paint(g, seconds, now);
        }
        POINT origin{};
        BLENDFUNCTION blend{AC_SRC_OVER, 0, 255, AC_SRC_ALPHA};
        UpdateLayeredWindow(window_, nullptr, &position, &size, surface_.dc, &origin, 0, &blend, ULW_ALPHA);
        if (moved && browser_.visible()) browser_.follow(browserAnchor());
    }

    HWND window_{};
    HMONITOR refreshMonitor_{};
    DWORD refreshRate_{60};
    UINT dpi_{96};
    Surface surface_;
    PrivateFontCollection fonts_;
    FontFamily family_;
    Browser browser_;
    Appearance appearance_;
    AppearanceEditor editor_;
    std::filesystem::path appearancePath_;
    GifArtwork gif_;
    Media media_;
    MediaState current_;
    std::shared_ptr<const std::vector<unsigned char>> coverBytes_;
    std::unique_ptr<Bitmap> cover_;
    unsigned coverColor_{};
    std::wstring battery_;
    const Clock::time_point started_{Clock::now()};
    Clock::time_point last_{started_}, nextStatus_{}, deadline_{};
    RECT rect_{};
    POINT start_{};
    Action pressed_{Action::None};
    Capsule state_{Capsule::Mini}, lastState_{Capsule::Mini};
    Clock::time_point showTrackUntil_{}, saveAppearanceAt_{};
    std::array<Hit, 18> hits_{};
    size_t hitCount_{};
    bool locked_{}, held_{}, physicalPress_{}, movedEnough_{}, dragging_{}, expanded_{}, timerFinished_{}, customFont_{};
    float x_{}, y_{}, targetX_{}, targetY_{}, anchorX_{}, anchorY_{}, grabX_{}, grabY_{};
    float width_{96}, height_{36}, blend_{1};
    float stretchX_{}, stretchY_{}, stretchCross_{}, trailX_{}, trailY_{}, grip_{};
};
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int) {
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    const auto existing = FindWindowW(L"DynamicIsland.Native", L"Dynamic Island");
    if (existing) return 0;
    const auto com = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    if (FAILED(com)) return 1;
    ULONG_PTR token{};
    GdiplusStartupInput input;
    if (GdiplusStartup(&token, &input, nullptr) != Ok) {
        CoUninitialize();
        return 1;
    }
    int result = 1;
    {
        Island island;
        if (island.open(instance)) {
            int count{};
            const auto args = CommandLineToArgvW(GetCommandLineW(), &count);
            if (args && count == 2) {
                std::error_code error;
                const auto path = std::filesystem::absolute(args[1], error);
                if (!error && std::filesystem::is_regular_file(path, error))
                    island.openAudio(path.wstring());
            }
            LocalFree(args);
            result = island.run();
        }
    }
    GdiplusShutdown(token);
    CoUninitialize();
    return result;
}
