#include "browser.h"
#include <wrl/event.h>
#include <shlobj.h>
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iterator>

using Microsoft::WRL::Callback;
using Microsoft::WRL::ComPtr;

namespace {
constexpr wchar_t browserClass[] = L"DynamicIsland.InAppBrowser";
constexpr wchar_t home[] = LR"html(
<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
html{color-scheme:dark}body{margin:0;min-height:100vh;display:grid;place-items:center;background:radial-gradient(ellipse at 50% 0%,#392921,#1a1716 72%);color:#f5e5d9;font:14px "Segoe UI",sans-serif;text-align:center}
p{margin:0;color:#c5a695}h1{margin:12px 0 10px;font:38px Georgia,serif;letter-spacing:-.04em}
nav{display:flex;gap:8px;justify-content:center;margin-top:25px}a{color:#f1d2be;text-decoration:none;border:1px solid #c7947840;border-radius:10px;padding:8px 13px;background:#c794781a}a:hover{background:#c7947840}
</style>
<main><p>I S L A N D &nbsp; B R O W S E R</p><h1>Where to?</h1><p>Search or paste a link in the bar above.</p>
<nav><a href="https://www.youtube.com/">YouTube</a><a href="https://soundcloud.com/">SoundCloud</a><a href="https://open.spotify.com/">Spotify</a></nav></main>
)html";

bool isHttp(const std::wstring& url) {
    return _wcsnicmp(url.c_str(), L"https://", 8) == 0 || _wcsnicmp(url.c_str(), L"http://", 7) == 0;
}

bool isLocalDocument(const wchar_t* uri) {
    return wcscmp(uri, L"about:blank") == 0 || _wcsnicmp(uri, L"data:text/html", 14) == 0;
}

std::wstring fromUtf8(const std::string& text) {
    if (text.empty()) return {};
    const int length = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), int(text.size()), nullptr, 0);
    if (!length) return {};
    std::wstring wide(length, L'\0');
    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), int(text.size()), wide.data(), length);
    return wide;
}

std::wstring readToolbar() {
    wchar_t exe[32768]{};
    GetModuleFileNameW(nullptr, exe, static_cast<DWORD>(std::size(exe)));
    const auto path = std::filesystem::path(exe).parent_path() / L"assets" / L"browser-toolbar.html";
    std::ifstream file(path, std::ios::binary);
    return fromUtf8({std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>()});
}

std::wstring searchUrl(const std::wstring& query) {
    const int length = WideCharToMultiByte(CP_UTF8, 0, query.data(), int(query.size()), nullptr, 0, nullptr, nullptr);
    std::string utf8(length, '\0');
    WideCharToMultiByte(CP_UTF8, 0, query.data(), int(query.size()), utf8.data(), length, nullptr, nullptr);
    std::wstring url = L"https://www.google.com/search?q=";
    constexpr wchar_t hex[] = L"0123456789ABCDEF";
    for (unsigned char c : utf8) {
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.') {
            url += wchar_t(c);
        } else {
            url += L'%';
            url += hex[c >> 4];
            url += hex[c & 15];
        }
    }
    return url;
}

void darkBackground(ICoreWebView2Controller* controller) {
    ComPtr<ICoreWebView2Controller2> color;
    if (SUCCEEDED(controller->QueryInterface(IID_PPV_ARGS(&color))))
        color->put_DefaultBackgroundColor(COREWEBVIEW2_COLOR{255, 39, 33, 30});
}
}

Browser::~Browser() {
    alive_.reset();
    if (toolbarController_) toolbarController_->Close();
    if (pageController_) pageController_->Close();
    if (IsWindow(window_)) DestroyWindow(window_);
}

void Browser::open(HWND owner, const RECT& anchor, const wchar_t* url) {
    if (!window_) {
        WNDCLASSW wc{};
        wc.hInstance = GetModuleHandleW(nullptr);
        wc.lpszClassName = browserClass;
        wc.lpfnWndProc = route;
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        RegisterClassW(&wc);
        if (!CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, browserClass, L"Island Browser",
                             WS_POPUP | WS_CLIPCHILDREN, 0, 0, 720, 480, owner,
                             nullptr, wc.hInstance, this)) return;
    }
    follow(anchor);
    ShowWindow(window_, SW_SHOW);
    SetForegroundWindow(window_);
    if (toolbarController_) toolbarController_->put_IsVisible(TRUE);
    if (pageController_) pageController_->put_IsVisible(TRUE);
    if (url) navigate(url);
    else {
        focusAddress_ = true;
        publishAddress();
    }
    if (!starting_ && !toolbar_ && error_.empty()) start();
}

void Browser::close() {
    if (toolbarController_) toolbarController_->put_IsVisible(FALSE);
    if (pageController_) pageController_->put_IsVisible(FALSE);
    if (window_) ShowWindow(window_, SW_HIDE);
    focusAddress_ = false;
}

bool Browser::visible() const { return window_ && IsWindowVisible(window_); }

void Browser::follow(const RECT& anchor) {
    if (!window_) return;
    MONITORINFO info{sizeof(info)};
    GetMonitorInfoW(MonitorFromRect(&anchor, MONITOR_DEFAULTTONEAREST), &info);
    const RECT area = info.rcWork;
    const UINT dpi = GetDpiForWindow(window_);
    const int gap = MulDiv(8, dpi, 96);
    const int width = std::min(MulDiv(740, dpi, 96), int(area.right - area.left));
    const int below = area.bottom - anchor.bottom - gap;
    const int above = anchor.top - area.top - gap;
    const bool useBelow = below >= MulDiv(500, dpi, 96) || below >= above;
    const int height = std::min(MulDiv(500, dpi, 96), std::max(gap, useBelow ? below : above));
    const int x = std::clamp(int((anchor.left + anchor.right - width) / 2), int(area.left), int(area.right) - width);
    const int y = useBelow ? anchor.bottom + gap : anchor.top - height - gap;
    SetWindowPos(window_, nullptr, x, y, width, height, SWP_NOZORDER | SWP_NOACTIVATE);
}

LRESULT CALLBACK Browser::route(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
    if (msg == WM_NCCREATE) {
        const auto create = reinterpret_cast<CREATESTRUCTW*>(l);
        const auto self = static_cast<Browser*>(create->lpCreateParams);
        self->window_ = hwnd;
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
    }
    const auto self = reinterpret_cast<Browser*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    return self ? self->message(msg, w, l) : DefWindowProcW(hwnd, msg, w, l);
}

LRESULT Browser::message(UINT msg, WPARAM w, LPARAM l) {
    switch (msg) {
    case WM_SIZE: layout(); return 0;
    case WM_DPICHANGED: layout(); return 0;
    case WM_CLOSE: close(); return 0;
    case WM_KEYDOWN:
        if (w == VK_ESCAPE) { close(); return 0; }
        break;
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: {
        PAINTSTRUCT paint{};
        const auto dc = BeginPaint(window_, &paint);
        RECT area{};
        GetClientRect(window_, &area);
        const auto brush = CreateSolidBrush(RGB(39, 33, 30));
        FillRect(dc, &area, brush);
        DeleteObject(brush);
        if (!page_ || !error_.empty()) {
            SetBkMode(dc, TRANSPARENT);
            SetTextColor(dc, RGB(235, 213, 195));
            SelectObject(dc, GetStockObject(DEFAULT_GUI_FONT));
            DrawTextW(dc, error_.empty() ? L"Opening Island Browser…" : error_.c_str(),
                      -1, &area, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        }
        EndPaint(window_, &paint);
        return 0;
    }
    }
    return DefWindowProcW(window_, msg, w, l);
}

void Browser::layout() {
    RECT area{};
    GetClientRect(window_, &area);
    const UINT dpi = GetDpiForWindow(window_);
    const int header = MulDiv(53, dpi, 96);
    const int round = MulDiv(28, dpi, 96);
    if (area.right && area.bottom) {
        auto region = CreateRoundRectRgn(0, 0, area.right + 1, area.bottom + 1, round, round);
        if (region && !SetWindowRgn(window_, region, TRUE)) DeleteObject(region);
    }
    if (toolbarController_) toolbarController_->put_Bounds({0, 0, area.right, std::min<LONG>(header, area.bottom)});
    if (pageController_) pageController_->put_Bounds({0, std::min<LONG>(header, area.bottom), area.right, area.bottom});
}

void Browser::fail(const wchar_t* message) {
    starting_ = false;
    error_ = message;
    InvalidateRect(window_, nullptr, TRUE);
}

void Browser::start() {
    PWSTR local{};
    std::filesystem::path profile;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &local)))
        profile = std::filesystem::path(local) / L"DynamicIsland" / L"Browser";
    CoTaskMemFree(local);
    if (profile.empty()) { fail(L"Could not open the Island browser profile."); return; }
    starting_ = true;
    const std::weak_ptr<int> live = alive_;
    const auto result = CreateCoreWebView2EnvironmentWithOptions(nullptr, profile.c_str(), nullptr,
        Callback<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler>(
            [this, live](HRESULT status, ICoreWebView2Environment* env) -> HRESULT {
                if (live.expired() || !IsWindow(window_)) return S_OK;
                if (FAILED(status) || !env) {
                    fail(L"Microsoft Edge WebView2 Runtime is required for Island Browser.");
                    return S_OK;
                }
                createView(env, true);
                createView(env, false);
                return S_OK;
            }).Get());
    if (FAILED(result)) fail(L"Microsoft Edge WebView2 Runtime is required for Island Browser.");
}

void Browser::createView(ICoreWebView2Environment* environment, bool toolbar) {
    const std::weak_ptr<int> live = alive_;
    const auto result = environment->CreateCoreWebView2Controller(window_,
        Callback<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler>(
            [this, live, toolbar](HRESULT status, ICoreWebView2Controller* controller) -> HRESULT {
                if (live.expired() || !IsWindow(window_)) return S_OK;
                if (FAILED(status) || !controller) { fail(L"Could not start Island Browser."); return S_OK; }
                auto& holder = toolbar ? toolbarController_ : pageController_;
                auto& view = toolbar ? toolbar_ : page_;
                holder = controller;
                if (FAILED(controller->get_CoreWebView2(&view))) {
                    fail(L"Could not start Island Browser.");
                    return S_OK;
                }
                darkBackground(controller);
                controller->put_IsVisible(visible());
                layout();
                if (toolbar) configureToolbar();
                else configureContent();
                if (toolbar_ && page_) starting_ = false;
                return S_OK;
            }).Get());
    if (FAILED(result)) fail(L"Could not start Island Browser.");
}

void Browser::configureToolbar() {
    const auto html = readToolbar();
    if (html.empty()) { fail(L"Keep assets/browser-toolbar.html next to DynamicIsland.exe."); return; }
    ComPtr<ICoreWebView2Settings> settings;
    if (SUCCEEDED(toolbar_->get_Settings(&settings))) {
        settings->put_AreDefaultContextMenusEnabled(FALSE);
        settings->put_AreDevToolsEnabled(FALSE);
        settings->put_IsZoomControlEnabled(FALSE);
    }
    EventRegistrationToken navigation{}, popup{}, command{};
    toolbar_->add_NavigationStarting(Callback<ICoreWebView2NavigationStartingEventHandler>(
        [](ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs* args) -> HRESULT {
            PWSTR uri{};
            if (SUCCEEDED(args->get_Uri(&uri)) && uri && !isLocalDocument(uri))
                args->put_Cancel(TRUE);
            CoTaskMemFree(uri);
            return S_OK;
        }).Get(), &navigation);
    toolbar_->add_NewWindowRequested(Callback<ICoreWebView2NewWindowRequestedEventHandler>(
        [](ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs* args) -> HRESULT {
            args->put_Handled(TRUE);
            return S_OK;
        }).Get(), &popup);
    const std::weak_ptr<int> live = alive_;
    toolbar_->add_WebMessageReceived(Callback<ICoreWebView2WebMessageReceivedEventHandler>(
        [this, live](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* args) -> HRESULT {
            if (live.expired()) return S_OK;
            PWSTR source{}, value{};
            if (SUCCEEDED(args->get_Source(&source)) && source && isLocalDocument(source) &&
                SUCCEEDED(args->TryGetWebMessageAsString(&value)) && value)
                handleToolbar(value);
            CoTaskMemFree(source);
            CoTaskMemFree(value);
            return S_OK;
        }).Get(), &command);
    toolbar_->NavigateToString(html.c_str());
}

void Browser::configureContent() {
    ComPtr<ICoreWebView2Settings> settings;
    if (SUCCEEDED(page_->get_Settings(&settings))) {
        settings->put_IsWebMessageEnabled(FALSE);
        settings->put_AreHostObjectsAllowed(FALSE);
    }
    EventRegistrationToken navigation{}, popup{}, changed{}, external{};
    const std::weak_ptr<int> live = alive_;
    page_->add_NavigationStarting(Callback<ICoreWebView2NavigationStartingEventHandler>(
        [](ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs* args) -> HRESULT {
            PWSTR uri{};
            if (SUCCEEDED(args->get_Uri(&uri)) && uri && !isHttp(uri) && !isLocalDocument(uri))
                args->put_Cancel(TRUE);
            CoTaskMemFree(uri);
            return S_OK;
        }).Get(), &navigation);
    page_->add_NewWindowRequested(Callback<ICoreWebView2NewWindowRequestedEventHandler>(
        [this, live](ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs* args) -> HRESULT {
            args->put_Handled(TRUE);
            PWSTR uri{};
            if (!live.expired() && SUCCEEDED(args->get_Uri(&uri)) && uri && isHttp(uri)) navigate(uri);
            CoTaskMemFree(uri);
            return S_OK;
        }).Get(), &popup);
    page_->add_SourceChanged(Callback<ICoreWebView2SourceChangedEventHandler>(
        [this, live](ICoreWebView2* view, ICoreWebView2SourceChangedEventArgs*) -> HRESULT {
            if (live.expired()) return S_OK;
            PWSTR uri{};
            if (SUCCEEDED(view->get_Source(&uri))) {
                address_ = uri && isHttp(uri) ? uri : L"";
                publishAddress();
            }
            CoTaskMemFree(uri);
            return S_OK;
        }).Get(), &changed);
    ComPtr<ICoreWebView2_18> schemes;
    if (SUCCEEDED(page_.As(&schemes))) {
        schemes->add_LaunchingExternalUriScheme(Callback<ICoreWebView2LaunchingExternalUriSchemeEventHandler>(
            [](ICoreWebView2*, ICoreWebView2LaunchingExternalUriSchemeEventArgs* args) -> HRESULT {
                return args->put_Cancel(TRUE);
            }).Get(), &external);
    }
    if (pending_.empty()) page_->NavigateToString(home);
    else {
        const auto url = std::move(pending_);
        pending_.clear();
        navigate(url);
    }
}

void Browser::navigate(const std::wstring& url) {
    if (!isHttp(url)) return;
    if (page_) page_->Navigate(url.c_str());
    else pending_ = url;
}

void Browser::publishAddress() {
    if (!addressReady_ || !toolbar_) return;
    toolbar_->PostWebMessageAsString((L"address:" + address_).c_str());
    if (focusAddress_ && visible()) {
        focusAddress_ = false;
        toolbarController_->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
        toolbar_->PostWebMessageAsString(L"focus");
    }
}

void Browser::handleToolbar(const std::wstring& command) {
    if (command == L"ready") {
        addressReady_ = true;
        publishAddress();
    } else if (command == L"close") {
        close();
    } else if (command == L"back") {
        if (page_) page_->GoBack();
    } else if (command == L"reload") {
        if (page_) page_->Reload();
    } else if (command.starts_with(L"navigate:") && command.size() <= 4105) {
        const auto input = command.substr(9);
        if (input.empty()) return;
        if (isHttp(input)) {
            navigate(input);
        } else {
            const auto domain = input.substr(0, input.find_first_of(L"/?#"));
            if (domain.find(L'.') != std::wstring::npos && input.find_first_of(L" \t\r\n") == std::wstring::npos &&
                domain.find_first_of(L"@:\\") == std::wstring::npos)
                navigate(L"https://" + input);
            else
                navigate(searchUrl(input));
        }
    }
}
