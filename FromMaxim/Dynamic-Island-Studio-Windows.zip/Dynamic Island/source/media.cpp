#include "media.h"
#include <windows.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.Control.h>
#include <winrt/Windows.Media.Core.h>
#include <winrt/Windows.Media.Playback.h>
#include <winrt/Windows.Storage.h>
#include <winrt/Windows.Storage.Streams.h>
#include <filesystem>
#include <chrono>

using namespace winrt::Windows::Media::Control;
using namespace winrt::Windows::Media::Playback;
using namespace std::chrono_literals;

namespace {
auto readCover(const winrt::Windows::Storage::Streams::IRandomAccessStreamReference& thumbnail)
    -> std::shared_ptr<const std::vector<unsigned char>> {
    if (!thumbnail) return {};
    try {
        const auto stream = thumbnail.OpenReadAsync().get();
        if (!stream || stream.Size() == 0 || stream.Size() > 2 * 1024 * 1024) return {};
        const auto size = static_cast<uint32_t>(stream.Size());
        winrt::Windows::Storage::Streams::DataReader reader(stream);
        if (reader.LoadAsync(size).get() != size) return {};
        auto bytes = std::make_shared<std::vector<unsigned char>>(size);
        reader.ReadBytes(*bytes);
        return bytes;
    } catch (const winrt::hresult_error&) {
        return {};
    }
}
}

Media::Media() : worker_([this](std::stop_token stop) { run(stop); }) {}

MediaState Media::state() {
    const std::scoped_lock lock(mutex_);
    return state_;
}

void Media::send(Command value) {
    command_.store(value);
}

void Media::open(std::wstring path) {
    const std::scoped_lock lock(mutex_);
    pendingFile_ = std::move(path);
    fileReady_ = true;
}

void Media::run(std::stop_token stop) {
    winrt::init_apartment(winrt::apartment_type::multi_threaded);
    GlobalSystemMediaTransportControlsSessionManager manager{nullptr};
    MediaPlayer player{nullptr};
    std::wstring localTitle;
    winrt::hstring lastSource;
    winrt::hstring coverSource;
    std::wstring coverTitle, coverArtist;
    std::shared_ptr<const std::vector<unsigned char>> cachedCover;
    std::chrono::steady_clock::time_point nextCoverAttempt;
    while (!stop.stop_requested()) {
        MediaState snapshot;
        const auto command = command_.exchange(Command::None);
        try {
            if (command == Command::ReleaseLocal && player) {
                player.Close();
                player = nullptr;
            }
            if (fileReady_) {
                std::wstring path;
                {
                    const std::scoped_lock lock(mutex_);
                    path.swap(pendingFile_);
                    fileReady_ = false;
                }
                const auto file = winrt::Windows::Storage::StorageFile::GetFileFromPathAsync(path).get();
                if (!player) player = MediaPlayer();
                player.Source(winrt::Windows::Media::Core::MediaSource::CreateFromStorageFile(file));
                localTitle = std::filesystem::path(path).stem().wstring();
                player.Play();
            }
            if (player) {
                const auto playback = player.PlaybackSession();
                if (command == Command::Toggle) {
                    if (playback.PlaybackState() == MediaPlaybackState::Playing) player.Pause();
                    else player.Play();
                }
                snapshot.active = snapshot.toggle = true;
                snapshot.title = localTitle;
                snapshot.artist = L"Local audio";
                snapshot.playing = playback.PlaybackState() == MediaPlaybackState::Playing;
            } else {
                if (!manager)
                    manager = GlobalSystemMediaTransportControlsSessionManager::RequestAsync().get();
                auto session = manager.GetCurrentSession();
                const auto isPlaying = [](const GlobalSystemMediaTransportControlsSession& item) {
                    if (!item) return false;
                    const auto info = item.GetPlaybackInfo();
                    return info && info.PlaybackStatus() == GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing;
                };
                if (!isPlaying(session)) {
                    for (const auto& candidate : manager.GetSessions()) {
                        if (isPlaying(candidate)) {
                            session = candidate;
                            break;
                        }
                        if (!session || candidate.SourceAppUserModelId() == lastSource)
                            session = candidate;
                    }
                }
                if (session) {
                    lastSource = session.SourceAppUserModelId();
                    snapshot.active = true;
                    switch (command) {
                    case Command::Previous: session.TrySkipPreviousAsync().get(); break;
                    case Command::Next: session.TrySkipNextAsync().get(); break;
                    case Command::Toggle:
                        if (!session.TryTogglePlayPauseAsync().get()) {
                            const auto info = session.GetPlaybackInfo();
                            if (info && info.PlaybackStatus() == GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing)
                                session.TryPauseAsync().get();
                            else
                                session.TryPlayAsync().get();
                        }
                        break;
                    default: break;
                    }
                    if (const auto info = session.GetPlaybackInfo()) {
                        snapshot.playing = info.PlaybackStatus() == GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing;
                        const auto controls = info.Controls();
                        snapshot.previous = controls.IsPreviousEnabled();
                        snapshot.toggle = controls.IsPlayPauseToggleEnabled() ||
                            (snapshot.playing ? controls.IsPauseEnabled() : controls.IsPlayEnabled());
                        snapshot.next = controls.IsNextEnabled();
                    }
                    if (const auto properties = session.TryGetMediaPropertiesAsync().get()) {
                        snapshot.title = properties.Title().c_str();
                        snapshot.artist = properties.Artist().c_str();
                        const auto now = std::chrono::steady_clock::now();
                        if (coverSource != lastSource || coverTitle != snapshot.title || coverArtist != snapshot.artist ||
                            (!cachedCover && now >= nextCoverAttempt)) {
                            coverSource = lastSource;
                            coverTitle = snapshot.title;
                            coverArtist = snapshot.artist;
                            cachedCover = readCover(properties.Thumbnail());
                            nextCoverAttempt = now + 2s;
                        }
                        snapshot.cover = cachedCover;
                    }
                }
            }
        } catch (const winrt::hresult_error&) {
            manager = nullptr;
        }
        {
            const std::scoped_lock lock(mutex_);
            state_ = std::move(snapshot);
        }
        for (int i = 0; i < 12 && !stop.stop_requested() && command_.load() == Command::None && !fileReady_; ++i)
            std::this_thread::sleep_for(45ms);
    }
    manager = nullptr;
    if (player) player.Close();
    winrt::uninit_apartment();
}
