#pragma once
#include <windows.h>
#include <ole2.h>
#include <WebView2.h>
#include <wrl/client.h>
#include <array>
#include <filesystem>
#include <functional>
#include <memory>
#include <string>
#include <vector>

struct Appearance {
    // A artwork, T title, S subtitle, M meter, P player, B browser, F file, C timer.
    std::array<std::string, 3> blocks{"AM", "ATM", "ATSPBFC"};
    int idleSeconds = 4, hover = 1, trackWake = 1, click = 1;
    int icon = 0, gifMini = 1, gifTrack = 1, gifFit = 0, gifSpeed = 100;
    int miniWidth = 96, trackWidth = 248, playerWidth = 440, radius = 30, padding = 12;
    int font = 0, fontSize = 100, opacity = 100, outline = 1, gradient = 1;
    int speed = 100, drag = 135;
    unsigned first = 0x392821, second = 0x1B1918;
    int artPalette = 0;
    std::shared_ptr<const std::vector<unsigned char>> gif;

    std::string encode() const;
    bool decode(const std::string& value);
};

std::filesystem::path settingsFolder();
bool readPreset(const std::filesystem::path& path, Appearance& result);
bool writePreset(const std::filesystem::path& path, const Appearance& value);
std::vector<std::filesystem::path> namedPresets();

class AppearanceEditor {
public:
    AppearanceEditor(Appearance& value, std::function<void()> changed);
    ~AppearanceEditor();
    void open(HWND owner);
    void refresh();
private:
    static LRESULT CALLBACK route(HWND, UINT, WPARAM, LPARAM);
    void start();
    void command(const std::wstring& value);
    void publish(bool gif);
    std::filesystem::path choose(bool save, bool gif);
    void status(const wchar_t* message);
    Appearance& value_;
    std::function<void()> changed_;
    HWND window_{};
    bool starting_{};
    std::shared_ptr<int> alive_ = std::make_shared<int>(0);
    Microsoft::WRL::ComPtr<ICoreWebView2Controller> controller_;
    Microsoft::WRL::ComPtr<ICoreWebView2> view_;
};
