#pragma once
#include <atomic>
#include <mutex>
#include <memory>
#include <string>
#include <thread>
#include <vector>

struct MediaState {
    std::wstring title, artist;
    std::shared_ptr<const std::vector<unsigned char>> cover;
    bool active{}, playing{};
    bool previous{}, toggle{}, next{};
};

class Media {
public:
    enum class Command { None, Previous, Toggle, Next, ReleaseLocal };
    Media();
    MediaState state();
    void send(Command value);
    void open(std::wstring path);
private:
    void run(std::stop_token stop);
    std::mutex mutex_;
    MediaState state_;
    std::wstring pendingFile_;
    std::atomic_bool fileReady_{};
    std::atomic<Command> command_{Command::None};
    std::jthread worker_;
};
