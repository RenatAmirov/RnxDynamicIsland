#include "custom.h"
#include <wrl/event.h>
#include <shlobj.h>
#include <commdlg.h>
#include <wincrypt.h>
#include <algorithm>
#include <charconv>
#include <fstream>
#include <sstream>

using Microsoft::WRL::Callback;
using Microsoft::WRL::ComPtr;
namespace {
constexpr wchar_t editorClass[] = L"DynamicIsland.Editor";
constexpr wchar_t editorUrl[] = L"https://island-editor.example/editor.html";
constexpr size_t maxGif = 4 * 1024 * 1024;
constexpr std::string_view magic = "DynamicIsland/1";

bool gifHeader(const std::vector<unsigned char>& bytes) {
    if (bytes.size() < 13 || bytes.size() > maxGif) return false;
    const std::string_view header(reinterpret_cast<const char*>(bytes.data()), 6);
    const auto width = bytes[6] | (bytes[7] << 8);
    const auto height = bytes[8] | (bytes[9] << 8);
    return (header == "GIF87a" || header == "GIF89a") && width > 0 && height > 0 &&
           width <= 1024 && height <= 1024;
}

std::wstring widen(const std::string& value) { return {value.begin(), value.end()}; }

std::wstring jsonString(const std::wstring& value) {
    std::wstring result = L"\"";
    for (wchar_t ch : value) {
        if (ch == L'"' || ch == L'\\') result += L'\\';
        if (ch >= 32) result += ch;
    }
    return result + L"\"";
}

std::filesystem::path assetsFolder() {
    wchar_t path[32768]{};
    GetModuleFileNameW(nullptr, path, static_cast<DWORD>(std::size(path)));
    return std::filesystem::path(path).parent_path() / L"assets";
}
}

std::string Appearance::encode() const {
    std::ostringstream out;
    for (const auto& row : blocks) {
        for (char id : row) if (id != ' ') out << id;
        out << '|';
    }
    const int fields[]{idleSeconds, hover, trackWake, click, icon, gifMini, gifTrack, gifFit, gifSpeed,
        miniWidth, trackWidth, playerWidth, radius, padding, font, fontSize, opacity, outline, gradient,
        speed, drag, static_cast<int>(first), static_cast<int>(second), artPalette};
    for (size_t i = 0; i < std::size(fields); ++i) out << (i ? "|" : "") << fields[i];
    return out.str();
}

bool Appearance::decode(const std::string& value) {
    if (value.size() > 256) return false;
    std::istringstream in(value);
    auto parsed = *this;
    std::string token;
    for (auto& row : parsed.blocks) {
        if (!std::getline(in, token, '|') || token.empty() || token.size() > 8) return false;
        row.clear();
        for (char id : token) {
            if (std::string_view("ATSMPBFC").find(id) == std::string_view::npos || row.find(id) != std::string::npos)
                return false;
            row += id;
        }
    }
    struct Field { int& value; int min; int max; };
    int firstColor{}, secondColor{};
    Field fields[]{
        {parsed.idleSeconds, 0, 60}, {parsed.hover, 0, 1}, {parsed.trackWake, 0, 1}, {parsed.click, 0, 1},
        {parsed.icon, 0, 2}, {parsed.gifMini, 0, 1}, {parsed.gifTrack, 0, 1}, {parsed.gifFit, 0, 1},
        {parsed.gifSpeed, 25, 250}, {parsed.miniWidth, 68, 220}, {parsed.trackWidth, 150, 460},
        {parsed.playerWidth, 320, 620}, {parsed.radius, 8, 50}, {parsed.padding, 6, 22},
        {parsed.font, 0, 2}, {parsed.fontSize, 80, 135}, {parsed.opacity, 55, 100},
        {parsed.outline, 0, 1}, {parsed.gradient, 0, 1}, {parsed.speed, 50, 200}, {parsed.drag, 0, 180},
        {firstColor, 0, 0xFFFFFF}, {secondColor, 0, 0xFFFFFF}, {parsed.artPalette, 0, 1}
    };
    for (auto& field : fields) {
        if (!std::getline(in, token, '|')) return false;
        int number{};
        const auto [end, error] = std::from_chars(token.data(), token.data() + token.size(), number);
        if (error != std::errc{} || end != token.data() + token.size()) return false;
        field.value = std::clamp(number, field.min, field.max);
    }
    if (std::getline(in, token, '|')) return false;
    parsed.first = static_cast<unsigned>(firstColor);
    parsed.second = static_cast<unsigned>(secondColor);
    *this = std::move(parsed);
    return true;
}

std::filesystem::path settingsFolder() {
    PWSTR path{};
    std::filesystem::path folder;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &path)))
        folder = std::filesystem::path(path) / L"DynamicIsland";
    CoTaskMemFree(path);
    return folder;
}

bool readPreset(const std::filesystem::path& path, Appearance& result) {
    std::error_code error;
    const auto size = std::filesystem::file_size(path, error);
    if (error || size > maxGif + 512) return false;
    std::ifstream in(path, std::ios::binary);
    std::string header, config;
    if (!std::getline(in, header) || header != magic || !std::getline(in, config)) return false;
    auto next = result;
    if (!next.decode(config)) return false;
    auto bytes = std::make_shared<std::vector<unsigned char>>(std::istreambuf_iterator<char>(in),
                                                             std::istreambuf_iterator<char>());
    if (!bytes->empty() && !gifHeader(*bytes)) return false;
    next.gif = bytes->empty() ? nullptr : bytes;
    result = std::move(next);
    return true;
}

bool writePreset(const std::filesystem::path& path, const Appearance& value) {
    if (path.empty()) return false;
    std::error_code error;
    std::filesystem::create_directories(path.parent_path(), error);
    auto temporary = path;
    temporary += L".tmp";
    {
        std::ofstream out(temporary, std::ios::binary | std::ios::trunc);
        out << magic << '\n' << value.encode() << '\n';
        if (value.gif) out.write(reinterpret_cast<const char*>(value.gif->data()), value.gif->size());
        out.close();
        if (!out) { std::filesystem::remove(temporary, error); return false; }
    }
    if (MoveFileExW(temporary.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) return true;
    std::filesystem::remove(temporary, error);
    return false;
}

std::vector<std::filesystem::path> namedPresets() {
    const auto folder = settingsFolder();
    std::vector<std::filesystem::path> files;
    if (folder.empty()) return files;
    std::error_code error;
    for (std::filesystem::directory_iterator it(folder / L"Presets", error), end;
         !error && it != end && files.size() < 200; it.increment(error)) {
        if (it->path().extension() == L".island" && it->is_regular_file(error))
            files.push_back(it->path());
    }
    std::sort(files.begin(), files.end());
    return files;
}

AppearanceEditor::AppearanceEditor(Appearance& value, std::function<void()> changed)
    : value_(value), changed_(std::move(changed)) {}

AppearanceEditor::~AppearanceEditor() {
    alive_.reset();
    if (controller_) controller_->Close();
    if (IsWindow(window_)) DestroyWindow(window_);
}

void AppearanceEditor::open(HWND owner) {
    if (!window_) {
        WNDCLASSW wc{};
        wc.hInstance = GetModuleHandleW(nullptr);
        wc.lpfnWndProc = route;
        wc.lpszClassName = editorClass;
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hbrBackground = GetSysColorBrush(COLOR_WINDOW);
        RegisterClassW(&wc);
        if (!CreateWindowExW(WS_EX_TOOLWINDOW, editorClass, L"Island Studio", WS_OVERLAPPEDWINDOW,
                             CW_USEDEFAULT, CW_USEDEFAULT, 960, 720, owner, nullptr, wc.hInstance, this)) return;
    }
    ShowWindow(window_, SW_SHOW);
    SetForegroundWindow(window_);
    if (!view_ && !starting_) start();
    if (controller_) controller_->put_IsVisible(TRUE);
}

void AppearanceEditor::refresh() { publish(true); }

LRESULT CALLBACK AppearanceEditor::route(HWND hwnd, UINT msg, WPARAM w, LPARAM l) {
    if (msg == WM_NCCREATE) {
        const auto create = reinterpret_cast<CREATESTRUCTW*>(l);
        const auto self = static_cast<AppearanceEditor*>(create->lpCreateParams);
        self->window_ = hwnd;
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
    }
    const auto self = reinterpret_cast<AppearanceEditor*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (self && msg == WM_SIZE && self->controller_) {
        RECT area{};
        GetClientRect(hwnd, &area);
        self->controller_->put_Bounds(area);
        return 0;
    }
    if (self && msg == WM_CLOSE) {
        ShowWindow(hwnd, SW_HIDE);
        if (self->controller_) self->controller_->put_IsVisible(FALSE);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, w, l);
}

void AppearanceEditor::start() {
    const auto folder = settingsFolder();
    if (folder.empty()) return;
    starting_ = true;
    const std::weak_ptr<int> live = alive_;
    const auto result = CreateCoreWebView2EnvironmentWithOptions(nullptr, (folder / L"Studio").c_str(), nullptr,
        Callback<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler>(
            [this, live](HRESULT status, ICoreWebView2Environment* environment) -> HRESULT {
                if (live.expired() || !IsWindow(window_)) return S_OK;
                if (FAILED(status) || !environment) {
                    starting_ = false;
                    SetWindowTextW(window_, L"Island Studio • WebView2 Runtime required");
                    return S_OK;
                }
                const auto result = environment->CreateCoreWebView2Controller(window_,
                    Callback<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler>(
                        [this, live](HRESULT status, ICoreWebView2Controller* controller) -> HRESULT {
                            if (live.expired() || !IsWindow(window_)) return S_OK;
                            starting_ = false;
                            if (FAILED(status) || !controller) return S_OK;
                            controller_ = controller;
                            controller_->get_CoreWebView2(&view_);
                            ComPtr<ICoreWebView2_3> assets;
                            if (!view_ || FAILED(view_.As(&assets))) return S_OK;
                            assets->SetVirtualHostNameToFolderMapping(L"island-editor.example", assetsFolder().c_str(),
                                                                      COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND_DENY);
                            EventRegistrationToken nav{}, messages{};
                            view_->add_NavigationStarting(Callback<ICoreWebView2NavigationStartingEventHandler>(
                                [](ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs* args) -> HRESULT {
                                    PWSTR url{};
                                    if (SUCCEEDED(args->get_Uri(&url)) && url && wcscmp(url, editorUrl) != 0)
                                        args->put_Cancel(TRUE);
                                    CoTaskMemFree(url);
                                    return S_OK;
                                }).Get(), &nav);
                            view_->add_WebMessageReceived(Callback<ICoreWebView2WebMessageReceivedEventHandler>(
                                [this, live](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* args) -> HRESULT {
                                    if (live.expired()) return S_OK;
                                    PWSTR url{}, message{};
                                    if (SUCCEEDED(args->get_Source(&url)) && url && wcscmp(url, editorUrl) == 0 &&
                                        SUCCEEDED(args->TryGetWebMessageAsString(&message)) && message)
                                        command(message);
                                    CoTaskMemFree(url);
                                    CoTaskMemFree(message);
                                    return S_OK;
                                }).Get(), &messages);
                            RECT area{};
                            GetClientRect(window_, &area);
                            controller_->put_Bounds(area);
                            controller_->put_IsVisible(IsWindowVisible(window_));
                            view_->Navigate(editorUrl);
                            return S_OK;
                        }).Get());
                if (FAILED(result)) starting_ = false;
                return S_OK;
            }).Get());
    if (FAILED(result)) {
        starting_ = false;
        SetWindowTextW(window_, L"Island Studio • WebView2 Runtime required");
    }
}

std::filesystem::path AppearanceEditor::choose(bool save, bool gif) {
    wchar_t path[32768]{};
    OPENFILENAMEW file{sizeof(file)};
    file.hwndOwner = window_;
    file.lpstrFile = path;
    file.nMaxFile = static_cast<DWORD>(std::size(path));
    file.lpstrFilter = gif ? L"GIF image\0*.gif\0" : L"Island preset\0*.island\0";
    file.lpstrDefExt = gif ? L"gif" : L"island";
    file.Flags = OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR | (save ? OFN_OVERWRITEPROMPT : OFN_FILEMUSTEXIST);
    if (!(save ? GetSaveFileNameW(&file) : GetOpenFileNameW(&file))) return {};
    return path;
}

void AppearanceEditor::status(const wchar_t* message) {
    if (view_) view_->PostWebMessageAsJson((L"{\"status\":" + jsonString(message) + L"}").c_str());
}

void AppearanceEditor::publish(bool gif) {
    if (!view_) return;
    std::wstring state = L"{\"config\":" + jsonString(widen(value_.encode()));
    if (gif) {
        std::wstring preview;
        if (value_.gif) {
            DWORD length{};
            CryptBinaryToStringW(value_.gif->data(), static_cast<DWORD>(value_.gif->size()),
                                 CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, nullptr, &length);
            preview.resize(length);
            if (length && CryptBinaryToStringW(value_.gif->data(), static_cast<DWORD>(value_.gif->size()),
                    CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, preview.data(), &length)) {
                preview.resize(length);
                preview.insert(0, L"data:image/gif;base64,");
            } else preview.clear();
        }
        state += L",\"gif\":" + jsonString(preview);
    }
    state += L",\"presets\":[";
    const auto files = namedPresets();
    for (size_t i = 0; i < files.size(); ++i) {
        if (i) state += L',';
        state += jsonString(files[i].stem().wstring());
    }
    state += L"]}";
    view_->PostWebMessageAsJson(state.c_str());
}

void AppearanceEditor::command(const std::wstring& value) {
    if (value == L"ready") { publish(true); return; }
    if (value.starts_with(L"apply:")) {
        if (value.size() >= 270 || std::any_of(value.begin() + 6, value.end(), [](wchar_t c) { return c > 127; }))
            return;
        std::string ascii;
        for (size_t i = 6; i < value.size(); ++i) ascii += static_cast<char>(value[i]);
        if (value_.decode(ascii)) changed_();
        return;
    }
    if (value == L"reset") {
        value_ = Appearance{};
    } else if (value == L"remove-gif") {
        value_.gif.reset();
        if (value_.icon == 2) value_.icon = 0;
    } else if (value == L"gif") {
        const auto path = choose(false, true);
        if (path.empty()) return;
        std::error_code error;
        if (std::filesystem::file_size(path, error) > maxGif || error) {
            status(L"GIF must be 4 MB or less.");
            return;
        }
        std::ifstream file(path, std::ios::binary);
        auto bytes = std::make_shared<std::vector<unsigned char>>(std::istreambuf_iterator<char>(file),
                                                                 std::istreambuf_iterator<char>());
        if (!gifHeader(*bytes)) { status(L"Choose a valid GIF up to 1024 × 1024."); return; }
        value_.gif = std::move(bytes);
        value_.icon = 2;
    } else if (value == L"export" || value == L"import") {
        const auto path = choose(value == L"export", false);
        if (path.empty()) return;
        if (value == L"export") {
            status(writePreset(path, value_) ? L"Preset exported with artwork." : L"Could not save preset.");
            return;
        }
        if (!readPreset(path, value_)) { status(L"Could not read this preset."); return; }
        status(L"Preset imported.");
    } else if (value.starts_with(L"save:") || value.starts_with(L"load:")) {
        const auto name = value.substr(5);
        if (name.empty() || name.size() > 32 || name.find_first_of(L"\\/:*?\"<>|.") != std::wstring::npos ||
            name.front() == L' ' || name.back() == L' ') { status(L"Enter a name of up to 32 letters or digits."); return; }
        const auto folder = settingsFolder();
        if (folder.empty()) return;
        const auto path = folder / L"Presets" / (name + L".island");
        if (value.starts_with(L"save:")) {
            status(writePreset(path, value_) ? L"Preset saved." : L"Could not save preset.");
            publish(false);
            return;
        }
        if (!readPreset(path, value_)) { status(L"Preset not found or invalid."); return; }
        status(L"Preset loaded.");
    } else return;
    changed_();
    publish(true);
}
