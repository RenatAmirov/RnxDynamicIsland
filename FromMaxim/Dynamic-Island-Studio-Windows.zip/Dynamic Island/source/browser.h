#pragma once
#include <windows.h>
#include <ole2.h>
#include <WebView2.h>
#include <wrl/client.h>
#include <memory>
#include <string>

class Browser {
public:
    ~Browser();
    void open(HWND owner, const RECT& anchor, const wchar_t* url = nullptr);
    void close();
    void follow(const RECT& anchor);
    bool visible() const;

private:
    static LRESULT CALLBACK route(HWND, UINT, WPARAM, LPARAM);
    LRESULT message(UINT, WPARAM, LPARAM);
    void start();
    void createView(ICoreWebView2Environment* environment, bool toolbar);
    void configureToolbar();
    void configureContent();
    void fail(const wchar_t* message);
    void layout();
    void navigate(const std::wstring& url);
    void publishAddress();
    void handleToolbar(const std::wstring& command);

    HWND window_{};
    bool starting_{}, addressReady_{}, focusAddress_{};
    std::wstring error_, pending_, address_;
    std::shared_ptr<int> alive_ = std::make_shared<int>(0);
    Microsoft::WRL::ComPtr<ICoreWebView2Controller> toolbarController_, pageController_;
    Microsoft::WRL::ComPtr<ICoreWebView2> toolbar_, page_;
};
